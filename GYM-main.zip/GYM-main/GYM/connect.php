<?php 
$link=mysqli_connect("localhost","root","","gymsysdb")or die("Can't Connect...");
	
?>